/*
#LUBYZ
BUY NO ENC +6282189474878
*/

require("./all/module.js")
const { color } = require('./all/function')
const { version } = require("./package.json")
//========== Setting Owner ==========//
global.owner = "6282393401622"
global.owner2 = "GANTI NOMER KALIAN"
global.namaowner = "Lubyz"
global.botname = "𝐂𝐫𝐚𝐬𝐡𝐞𝐫-𝐅𝐨𝐫𝐂𝐫𝐚𝐬𝐡𝐞𝐫"
//======== Setting Bot & Link ========//
global.namabot = "𝐂𝐫𝐚𝐬𝐡𝐞𝐫-𝐅𝐨𝐫𝐂𝐫𝐚𝐬𝐡𝐞𝐫" 
global.namabot2 = "𝐂𝐫𝐚𝐬𝐡𝐞𝐫-𝐅𝐨𝐫𝐂𝐫𝐚𝐬𝐡𝐞𝐫"
global.foother = "© - Lubyz"
global.versibot = "9.0.0"
global.idsaluran = false
global.linkgc = 'https://whatsapp.com/channel/0029VasOixn8aKvAfv8mfQ0A'
global.linksaluran = "https://whatsapp.com/channel/0029VasOixn8aKvAfv8mfQ0A"
global.linkyt = 'https://youtube.com/@techwithmrad2'
global.linktele = 'https://t.me/techwithmradofficiall'
global.packname = "mrad V9"
global.author = "mrad"

//========== Setting Event ==========//
global.welcome = true
global.autoread = false
global.anticall = false
global.owneroff = false


//========== Setting Panel Server  1==========//
global.domain = ""
global.apikey = ""
global.capikey = ""
//======== egg & loc biasanya sama jadi gausah ========//
global.egg = "15"
global.loc = "1"

//========= Setting Message =========//
global.msg = {
"error": "Maaf terjadi kesalahan..",
"done": "Succesfully ✅", 
"wait": "Bot Sedang Memproses Tunggu Sebentar . . .", 
"group": "<𝙈𝙖𝙪 𝙟𝙖𝙙𝙞 𝙥𝙧𝙚𝙢𝙞𝙪𝙢? 𝙁𝙤𝙡𝙡𝙤𝙬 𝙙𝙪𝙡𝙪>\n\nhttps://whatsapp.com/channel/0029VasOixn8aKvAfv8mfQ0A", 
"private": "<𝙈𝙖𝙪 𝙟𝙖𝙙𝙞 𝙥𝙧𝙚𝙢𝙞𝙪𝙢? 𝙁𝙤𝙡𝙡𝙤𝙬 𝙙𝙪𝙡𝙪>\n\https://whatsapp.com/channel/0029VasOixn8aKvAfv8mfQ0A", 
"admin": "<𝙈𝙖𝙪 𝙟𝙖𝙙𝙞 𝙥𝙧𝙚𝙢𝙞𝙪𝙢? 𝙁𝙤𝙡𝙡𝙤𝙬 𝙙𝙪𝙡𝙪>\n\https://whatsapp.com/channel/0029VasOixn8aKvAfv8mfQ0A", 
"adminbot": "<𝙈𝙖𝙪 𝙟𝙖𝙙𝙞 𝙥𝙧𝙚𝙢𝙞𝙪𝙢? 𝙁𝙤𝙡𝙡𝙤𝙬 𝙙𝙪𝙡𝙪>\n\https://whatsapp.com/channel/0029VasOixn8aKvAfv8mfQ0A", 
"owner": "<𝙈𝙖𝙪 𝙟𝙖𝙙𝙞 𝙥𝙧𝙚𝙢𝙞𝙪𝙢? 𝙁𝙤𝙡𝙡𝙤𝙬 𝙙𝙪𝙡𝙪>\n\nhttps://whatsapp.com/channel/0029VasOixn8aKvAfv8mfQ0A", 
"developer": "<𝙈𝙖𝙪 𝙟𝙖𝙙𝙞 𝙥𝙧𝙚𝙢𝙞𝙪𝙢? 𝙁𝙤𝙡𝙡𝙤𝙬 𝙙𝙪𝙡𝙪>\n\https://whatsapp.com/channel/0029VasOixn8aKvAfv8mfQ0A", 
"premium": "<𝙈𝙖𝙪 𝙟𝙖𝙙𝙞 𝙥𝙧𝙚𝙢𝙞𝙪𝙢? 𝙁𝙤𝙡𝙡𝙤𝙬 𝙙𝙪𝙡𝙪>\n\nhttps://whatsapp.com/channel/0029VasOixn8aKvAfv8mfQ0A"

}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})